﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;
using RabbitMQ.Client;
using RabbitMQSenderConsumer.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace RabbitMQSenderConsumer.RabbitMQ
{
    public class RabbitMQClient
    {

        private static ConnectionFactory _factory;
        private static IConnection _connection;
        private static IModel _model;
        private static string ExchangeName;
        private static string QueueName;
        private static string routingKey;
        private static string exchangeType;
        private static QueueDeclareOk _queueDeclareResponse;

        // Adding JSON file into IConfiguration.
        


        public RabbitMQClient()
        {
            IConfiguration config = new ConfigurationBuilder().AddJsonFile("appsettings.json", true, true).Build();
            var queueConfig = config.GetSection("QueuesExchange");
            ExchangeName = queueConfig["ExchangeName"];
            QueueName = queueConfig["InBoundQueue"];
            routingKey = queueConfig["routingKey"];
            exchangeType = queueConfig["exchangeType"];
            var hostConfig = config.GetSection("RabbitMQHostSetting");
            CreateConnection(username: hostConfig["UserName"], password: hostConfig["Password"], virtualHost: hostConfig["VirtualHost"], hostname: hostConfig["HostName"]);

        }

        private static void CreateConnection(string username, string password, string virtualHost, string hostname)
        {

            _factory = new ConnectionFactory
            {
                UserName = username,
                Password = password,
                VirtualHost = virtualHost,
                Port = AmqpTcpEndpoint.UseDefaultPort,
                HostName = hostname,
            };
            _connection = _factory.CreateConnection();
            _model = _connection.CreateModel();
            _model.ExchangeDeclare(ExchangeName, exchangeType);
            _queueDeclareResponse = _model.QueueDeclare(QueueName, true, false, false, null);
            _model.QueueBind(QueueName, ExchangeName, routingKey);

        }

        public void Close()
        {
            _connection.Close();
        }
        public void SendMessage(string messageData)
        {
            _model.BasicPublish(ExchangeName, routingKey, null, Encoding.UTF8.GetBytes(messageData));
        }



        public void ConsumeMessage()
        {
            var consumer = new QueueingBasicConsumer(_model);
            _model.BasicConsume(queue: QueueName, autoAck: false, consumer: consumer);
            for (int i = 0; i < _queueDeclareResponse.MessageCount; i++)
            {
                var ea = consumer.Queue.Dequeue();
                var body = ea.Body;
                var message = Encoding.UTF8.GetString(body);
                Console.WriteLine(" [x] Received {0}", message);

                //Saving Logs using NLog
                 MaintainLogs.Log(correlationId: Guid.NewGuid(), message: message, result: "success");

                //Set Acknowledgement to true
                _model.BasicAck(ea.DeliveryTag, true);
            }
            Console.WriteLine("Finished processing {0} messages. at {1}", _queueDeclareResponse.MessageCount, DateTime.UtcNow);
        }



    }
}
