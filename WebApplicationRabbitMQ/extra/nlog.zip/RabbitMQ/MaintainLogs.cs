﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NLog;
using NLog.Extensions.Logging;
using System;
 
using System.IO;
using System.Reflection;

namespace RabbitMQSenderConsumer.RabbitMQ
{
  public static class MaintainLogs
    {
        /// <summary>
        /// Method to Save Logs Using NLog
        /// </summary>
        /// <param name="correlationId"></param>
        /// <param name="message"></param>
        /// <param name="result"></param>
        public static void Log(Guid correlationId, string message, string result)
        {
            var servicesProvider = BuildDi();
            Logger logger = LogManager.GetCurrentClassLogger();
            LogEventInfo theEvent = new LogEventInfo(NLog.LogLevel.Debug, "Inbound Queue", message);
            theEvent.Properties["CorrelationId"] = correlationId;
            theEvent.Properties["Result"] = result;
            logger.Log(theEvent);
            LogManager.Shutdown();

        }
        private static IServiceProvider BuildDi()
        {
            var services = new ServiceCollection();
            services.AddSingleton<ILoggerFactory, LoggerFactory>();
            services.AddSingleton(typeof(ILogger<>), typeof(Logger<>));
            services.AddLogging((builder) => builder.SetMinimumLevel(Microsoft.Extensions.Logging.LogLevel.Debug));
            var serviceProvider = services.BuildServiceProvider();
            var loggerFactory = serviceProvider.GetRequiredService<ILoggerFactory>();
            //configure NLog
            loggerFactory.AddNLog(new NLogProviderOptions { CaptureMessageTemplates = true, CaptureMessageProperties = true });
            NLog.LogManager.LoadConfiguration("nlog.config");
            return serviceProvider;
        }
    }
}
