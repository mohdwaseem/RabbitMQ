﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RabbitMQSenderConsumer.Models
{
    public class LeanIqamaModel
    {

        public int Id { get; set; }
        public string ProfilePicKey { get; set; }
        public string FullName { get; set; }
        public int IdentityNo { get; set; }
        public int Gender { get; set; }
        public object Nationality { get; set; }
        public int PersonType { get; set; }
        public string BirthDate { get; set; }
        public string PassportNumber { get; set; }
        public string SponsorName { get; set; }
        public string VisaNumber { get; set; }
        public string VisaSource { get; set; }
        public string Job { get; set; }
        public string ApproveDate { get; set; }
        public string HospitalNameAr { get; set; }
        public bool Hearing { get; set; }
        public bool BloodPressure { get; set; }
        public bool HeartAndChest { get; set; }
        public bool Neural { get; set; }
        public bool Hernia { get; set; }
        public bool VaricoseVeins { get; set; }
        public bool Limbs { get; set; }
        public bool ChestXRay { get; set; }
        public bool Belly { get; set; }
        public bool Skin { get; set; }
        public int Psycho { get; set; }
        public int Pregnancy { get; set; }
        public bool LeftEye { get; set; }
        public bool RightEye { get; set; }
        public int RightEyeVisionWithGlasses { get; set; }
        public int LeftEyeVisionWithGlasses { get; set; }
        public bool BloodSugar { get; set; }
        public bool Malaria { get; set; }
        public bool ViralHepatitisB { get; set; }
        public bool ViralHepatitisC { get; set; }
        public bool Syphilis { get; set; }
        public bool Aids { get; set; }
        public bool UrineSugar { get; set; }
        public bool UrineClear { get; set; }
        public bool StoolParasites { get; set; }
        public bool StoolSalamonia { get; set; }
        public bool StoolShigla { get; set; }
        public int FinalResult { get; set; }
        public DateTime ResultExpiryDate { get; set; }
        public int CertificateID { get; set; }
        public string Notes { get; set; }
        public List<string> Warnings { get; set; }
        public List<string> Restrictions { get; set; }
    }
}
