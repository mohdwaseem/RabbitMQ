﻿using Newtonsoft.Json;
using RabbitMQSenderConsumer.Models;
using RabbitMQSenderConsumer.RabbitMQ;
using System;
using System.Collections.Generic;
using System.IO;

namespace RabbitMQSenderConsumer
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                RabbitMQClient client = new RabbitMQClient();
                Console.WriteLine("Please type s for sending and r for consuming");
                var choice = Console.ReadLine();
                switch (choice)
                {
                    case "s":
                        Console.WriteLine("Please enter certificateId");
                        int certificateID = Convert.ToInt16(Console.ReadLine());
                        for (int i = 0; i < 50; i++)
                        {
                            client.SendMessage(ReadDataFromJson(i, certificateID));
                        }
                        Console.WriteLine("Mesage Sent");
                        Console.ReadLine();
                        break;
                    case "r":
                        Console.WriteLine("-------Reading Messages-------- ");
                        client.ConsumeMessage();
                        Console.ReadLine();
                        break;

                    default:
                        Console.WriteLine("Invalid selection. Please select s or r.");
                        Console.ReadLine();
                        break;
                }
                client.Close();
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
        }
        public static string ReadDataFromJson(int counter, int certificateId)
        {
            List<LeanIqamaModel> leanList = new List<LeanIqamaModel>();
            leanList.Add(item: new LeanIqamaModel
            {
                Id = counter,
                ProfilePicKey = "Profile-Key: " + counter,
                FullName = "Name- " + counter,
                IdentityNo = counter,
                PassportNumber = "PASSPORT: " + counter,
                ResultExpiryDate = DateTime.UtcNow.AddMinutes(counter),
                CertificateID = certificateId
            });
            string outPutJson = JsonConvert.SerializeObject(leanList);
            return outPutJson;
        }
    }
}
